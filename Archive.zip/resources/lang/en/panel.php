<?php

return [
    'site_title' => 'RSN Kedah Web App',
];
